import '../src/x-1891682-board-app';

const el = document.createElement('DIV');
document.body.appendChild(el);

el.innerHTML = `		
	<x-1891682-board-app></x-1891682-board-app>
`;
