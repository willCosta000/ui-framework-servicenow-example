// Tests for x-1835194-list-incident
describe('Test stub', () => {
	it('should be true', () => {
		expect(true).toBe(true);
	});
});
